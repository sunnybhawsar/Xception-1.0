package com.example.wallchanger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import android.app.Service;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.util.Log;

public class Serve extends Service {

	int wallResource;
	int x = 0;
	
	List<Integer> list;
	
	WallpaperManager wm;

	
	
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
	}

	@Override
	@Deprecated
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub

		wm = (WallpaperManager) this
				.getSystemService(Context.WALLPAPER_SERVICE);

		
	 list = new ArrayList<Integer>();
		list.add(R.drawable.ic_launcher);
		list.add(R.drawable.r);
		list.add(R.drawable.s);
		list.add(R.drawable.t);

		
		// Inserted millisInFuture and countDownInterval
		// 1 second=1,000 miliseconds
		// countDownInterval long time out
		CountDownTimer ct = new Timer(1000000, 15000);
		// new Timer(millisInFuture, countDownInterval);

		ct.start();
		super.onStart(intent, startId);
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	public class Timer extends CountDownTimer {

		public Timer(long millisInFuture, long countDownInterval) {
			super(1000000, 15000);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onFinish() {
			// TODO Auto-generated method stub

		}

		@Override
		public void onTick(long millisUntilFinished) {
			// TODO Auto-generated method stub

			if (x < 4) {
				wallResource = list.get(x);

				try {

					wm.setResource(wallResource);
					x++;

				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.d("not set", "exception");
					e.printStackTrace();
				}
			} else {
				x = 0;

			}

		}

	}

}
