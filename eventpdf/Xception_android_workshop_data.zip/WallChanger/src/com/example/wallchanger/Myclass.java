package com.example.wallchanger;

public class Myclass {

}
