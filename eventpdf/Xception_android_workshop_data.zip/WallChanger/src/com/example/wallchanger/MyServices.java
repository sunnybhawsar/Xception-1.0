package com.example.wallchanger;

import java.util.List;

import android.app.Service;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.os.CountDownTimer;
import android.os.IBinder;

public class MyServices extends Service {

	int wallResource;
	int x = 0;
	List<Integer> list;
	WallpaperManager wm;

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	@Override
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub
		super.onStart(intent, startId);

		wm = (WallpaperManager) this
				.getSystemService(Context.WALLPAPER_SERVICE);

	}

	class Timer extends CountDownTimer {

		public Timer(long millisInFuture, long countDownInterval) {
			super(millisInFuture, countDownInterval);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onTick(long millisUntilFinished) {
			// TODO Auto-generated method stub

			if(x<4){
				
				wallResource = list.get(x);
				
				
				
				try {
					
					wm.setResource(wallResource);
					x++;
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
					
				}

			}
			
		}

		@Override
		public void onFinish() {
			// TODO Auto-generated method stub

		}

	}

}
