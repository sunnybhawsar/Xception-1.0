package com.example.wallchanger;

public class Servex {

}
