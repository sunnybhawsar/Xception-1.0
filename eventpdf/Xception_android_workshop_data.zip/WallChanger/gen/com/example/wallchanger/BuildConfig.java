/** Automatically generated file. DO NOT MODIFY */
package com.example.wallchanger;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}